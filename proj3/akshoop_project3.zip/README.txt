README for Alex Shoop CS 3013 Project 3

To compile:
make

To clean up:
make clean

To run addem:
./addem number_of_threads end_number_range

To run life:
./life number_of_threads filename number_of_generations [print] [input]
where [print] and [input] are optional

My addem program functions properly with 3 test cases done within the script_text.txt

However I was only able to print out the initial generation 0 for my life program.
I was not able to finish the rest of the life program.
I would suggest the graders please take a look at my life.c code and
grade my life program where they see reasonable.
